# genmods.R

# this file contains code to generate simulated data to test the infiniteHorizon package

#' Generative model for testing infiniteHorizon
#'
#' \code{genmod1} generates simulated data from a simple generative model with two
#'   possible actions at each time point.
#'
#' @param n Sample size of simulated data set.
#' @param capT Number of time points for each subject.
#' @param mu Policy for generating actions; can be the function \code{final_policy}
#'   as returned by \code{vl}. If \code{NULL}, each of the two treatments is assigned
#'   with probability 0.5. Defaults to \code{NULL}.
#' @param init A data frame returned by \code{genmod1} to add on to. Defaults to
#'   \code{NULL}, in which case a new data frame is returned.
#'
#' @return A data frame with columns \code{id}, a patient identifier;
#'   \code{s1}, the first state variable; \code{s2}, the second state variable;
#'   \code{act} the treatment (action); and \code{util}, the utility.
#'
#' @examples
#' data = genmod1(50, 24)
#' head(data)
#'
#' @export
#'
genmod1 = function(n, capT, mu = NULL, init = NULL) {

  # function to generate utilities
  utility = function(df, row) {
    return(1 + df$s1[row] + df$s2[row] + 0.8 * (2 * df$act[row] - 1) * (df$s1[row] + df$s2[row]) + rnorm(1, 0, 0.5))
  }

  # function to generate probabilities for each treatment
  gen_trt_probs = function(df, row) {
    if (is.null(mu)) {
      return(c(0.5, 0.5))
    } else {
      return(mu(df, row))
    }
  }

  # function to generate treatment assignment
  gen_trt = function(probs) {
    if (!is.na(probs[2])) {
    return(rbinom(1, 1, probs[2]))
    } else {
      return(NA)
    }
  }

  # create a data frame to fill
  df = data.frame(id = rep(1:n, each = capT), time = NA,
                  s1 = rnorm(n * capT, 0, 1), s2 = rnorm(n * capT, 0, 1),
                  act = NA, util = NA, prob = NA)

  # if initial state variables are provided, add them here
  if (!is.null(init)) df = rbind(init, df)

  # loop through unique IDs and add time variable
  for (id in unique(df$id)) {
    indices = which(df$id == id)
    df$time[indices] = 1:length(indices)
  }  # end loop through unique IDs

  # sort data frame by id and time
  df = df[order(df$id, df$time), ]

  # generate treatment assignment and utility
  for (i in 1:nrow(df)) {
    if (is.na(df$act[i])) {
      temp_probs = gen_trt_probs(df, i)
      df$act[i] = gen_trt(temp_probs)
      df$prob[i] = temp_probs[df$act[i] + 1]
    }
    if (is.na(df$util[i])) df$util[i] = utility(df, i)
  }

  return(df)

}  # end function genmod1

# genmod2 is currently under construction

#' Second generative model for testing infiniteHorizon
#'
#' \code{genmod2} generates simulated data from a simple generative model with
#'   three possible actions at each time point.
#'
#' @param n Sample size of simulated data set.
#' @param capT Number of time points for simulated data set.
#' @param burn Number of burn-in time points per patient. Defaults to 50.
#' @param mu Policy for generating actions; can be the function \code{final_policy}
#'   as returned by \code{vl}, assuming that linear basis functions and two time points
#'   were used to estimate \code{final_policy}. If \code{NULL}, treatment 0 is assigned
#'   with probability 0.5, treatment 1 with probability 0.25, and treatment 2 with
#'   probability 0.25. Defaults to \code{NULL}.
#'
#' @return A data frame with columns \code{id}, a patient identifier;
#'   \code{s1}, the first state variable; \code{s2}, the second state variable;
#'   \code{act} the treatment (action); and \code{util}, the utility.
#'
#' @examples
#' data = genmod2(50, 24)
#' head(data)
#'
genmod2 = function(n, capT, burn = 50, mu = NULL) {

  # action generating policy
  if (is.null(mu)) {
    gen_trt = function(x) return(c(0.25, 0.25, 0.5))
  } else {
    gen_trt = function(x) {
      if (sum(is.na(x) > 0)) {
        return(c(0.25, 0.25, 0.5))
      } else {
        return(mu(x))
      }
    }  # end function gen_trt
  }  # end else mu is not null

  # utility function
  u = function(s1, a, s2) return(2 * s2[1] + s2[2] - 0.25 * (2 * as.numeric(a == 1) - 1))

  # set total number of time points, including burn-in time points
  capT = capT + burn

  # create data frame to fill
  full.data = data.frame()

  # loop through patients
  for (i in 1:n) {

    # create temporary data frame to fill with data on one subject

    dat = data.frame()

    # set initial states and add to dat
    t1 = rnorm(1)
    t2 = rnorm(1)
    dat = rbind(dat, c(i, t1, t2, sample(c(0, 1, 2), size = 1,
                                         prob = gen_trt(c(1, t1, NA, t2, NA))), NA))

    # loop through time points
    for (t in 2:capT) {

      t1 = 0.75 * (2 * as.integer(dat[t - 1, 4] == 1) - 1) * dat[t - 1, 2] + rnorm(1, 0, 0.25)
      t2 = 0.75 * (1 - 2 * as.integer(dat[t - 1, 4] == 1)) * dat[t - 1, 3] + rnorm(1, 0, 0.25)
      dat = rbind(dat, c(i, t1, t2, sample(c(0, 1, 2), size = 1,
                                           prob = gen_trt(c(1, t1, dat[t - 1, 2], t2, dat[t - 1, 3]))), NA))
      dat[t - 1, 5] = u(c(dat[t - 1, 2], dat[t - 1, 3]), dat[t - 1, 4], c(t1, t2))

    }  # end loop through time points

    # remove burn-in time points
    dat = dat[-(1:burn), ]

    # set variable names and add to full data frame
    names(dat) = c("v1", "v2", "v3", "v4", "v5")
    full.data = rbind(full.data, dat)

  }  # end loop through patients

  # set names of full data frame
  names(full.data) = c("id", "s1", "s2", "act", "util")

  # utility is missing for the last time point per subject
  # these utilities are never used for estimation -- set them equal to 0 (arbitrarily)
  full.data$util[which(is.na(full.data$util))] = 0

  # return full data frame
  return(full.data)

}  # end function genmod2



