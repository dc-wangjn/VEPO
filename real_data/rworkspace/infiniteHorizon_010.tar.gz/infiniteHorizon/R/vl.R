# vl.R

# © 2019, The University of North Carolina at Chapel Hill. All rights reserved.

# this file contains the vl (V-learning) function

#' V-learning
#'
#' \code{vl} estimates a dynamic treatment regime using V-learning.
#'
#' @param data A data frame.
#' @param id A character string specifying the name of the patient identifier
#'   variable in \code{data}.
#' @param util A character string giving the name of a variable in \code{data} with utilities.
#' @param act A character string giving the name of a variable in \code{data} with
#'   actions. \code{data[[act]]} must be an object that can be coerced to a factor.
#' @param state_value A list of parameters for modeling the state-value function. Components should include
#'   \code{vars}, a character vector with the names of the variables in \code{data} to use
#'   when fitting the state-value function; \code{num_lags}, a numeric vector of the same length
#'   as \code{vars} specifying the number of time points (including the current time point) for each
#'   variable to use; \code{basis}, any unambiguous substring of "linear", "polnomial", or "gaussian",
#'   specifying the type of basis function to include (defaults to "linear"); \code{degree}, the
#'   degree of polynomial if a polynomial basis is requested (defaults to 2); \code{sigma}, the
#'   bandwidth parameter if a Gaussian basis is requested (defaults to 1); and \code{kernel_means},
#'   the means of the Gaussian basis functions (defaults to \code{NULL}, in which case the means of
#'   initial state variables are used).
#' @param policy_class A list with the same components as \code{state_value}, specifying how the
#'   policy class should be modeled.
#' @param propensity A list with the same components as \code{state_value}, specifying how the
#'   propensity score (observational policy) should be modeled. Defaults to \code{NULL}, in which case
#'   assumed to be the same as \code{policy_class}.
#' @param disc The discount factor; a real number strictly between 0 and 1. Defaults to 0.9.
#' @param lambdas A vector of penalty parameters for fitting the state-value function. The best
#'   parameter will be selected using cross-validation. Defaults to \code{c(0.1, 0.5, 1)}. If
#'   only one value is given, there will be no cross-validation.
#' @param tau The penalty parameter for estimating the policy. Defaults to 0.001.
#' @param K The number of folds in cross-validation to select a value of lambda. Defaults to 5.
#' @param alpha The complement of the confidence level for the confidence interval for value.
#'   Defaults to 0.05.
#' @param center_scale Logical; if \code{TRUE}, state variables are rescaled to be
#'   between 0 and 1. Defaults to \code{TRUE}.
#' @param ref The reference distribution. Can be a vector
#'   giving the means of the state variables under the reference distribution.
#'   If \code{NULL}, the reference distribution is estimated from the states in the data.
#'   Defaults to \code{NULL}.
#' @param mu The observational policy, a function mapping a row of \code{data}
#'   into a vector of probabilities of length \code{nlevels(as.factor(data[[act]]))}.
#'   Defaults to \code{NULL}.
#' @param pred_prob A vector of length \code{nrow(data)} with predicted probabilties
#'   of observed actions under the observational policy. If \code{NULL}, predicted
#'   probabilities are calculated using \code{mu}. If \code{mu} is also \code{NULL},
#'   predicted probabilities are computed by fitting a (multinomial) logistic regression
#'   model to observed actions. If both \code{pred_prob} and \code{mu} are specified,
#'   \code{mu} is ignored. Defaults to \code{NULL}.
#' @param seed Random number seed. If provided, seed is set prior to simulated annealing.
#'   If \code{NULL}, no seed is set. Defaults to \code{NULL}.
#'
#' @return An object of class infiniteHorizon, a list with the following components:
#'   \code{beta_hat}, which defines the estimated policy; \code{theta_hat}, which defines
#'   the estimated state value function; \code{final_policy}, a function mapping a data
#'   frame with the same columns as \code{data} and a row number
#'   into a matrix of probabilities for each action
#'   as recommended by the estimated policy for the given row of the given data frame;
#'   \code{val_param}, the parametric value estimate;
#'   \code{conf_int}, a confidence interval for the parametric value estimate;
#'   \code{se_hat}, the estimated standard error of the parametric value estimate;
#'   \code{best_lambda}, the best value of lambda selected by cross-validation; and
#'   \code{pred_prob}, the predicted propensity scores.
#'
#' @export
#'
vl = function(data, id, util, act, state_value, policy_class, propensity = NULL, disc = 0.9,
              lambdas = c(0.1, 0.5, 1), tau = 0.001, K = 5, alpha = 0.05,
              center_scale = T, ref = NULL, mu = NULL, pred_prob = NULL, seed = NULL) {

  # check and format data -------------------------------------------------------------------------

  # create design matrix for fitting state-value function
  state_value_design = make_design(data = data, vars = state_value$vars, id = id,
                                   num_lags = state_value$num_lags,
                                   basis = ifelse(is.null(state_value$basis), "linear", state_value$basis),
                                   degree = ifelse(is.null(state_value$degree), 2, state_value$degree),
                                   sigma = ifelse(is.null(state_value$sigma), 1, state_value$sigma),
                                   kernel_means = state_value$kernel_means)
  S1 = state_value_design$design_matrix

  # create design matrix for estimating optimal policy
  policy_design = make_design(data = data, vars = policy_class$vars, id = id,
                              num_lags = policy_class$num_lags,
                              basis = ifelse(is.null(policy_class$basis), "linear", policy_class$basis),
                              degree = ifelse(is.null(policy_class$degree), 2, policy_class$degree),
                              sigma = ifelse(is.null(policy_class$sigma), 1, policy_class$sigma),
                              kernel_means = policy_class$kernel_means)
  S2 = policy_design$design_matrix

  # create design matrix for fitting observational policy
  # and get indices of all rows that have sufficient data for the lag times for all design matrices
  if (is.null(propensity)) {
    S3 = S2
    all_ind = as.logical(pmin(state_value_design$indices, policy_design$indices))
  } else {
    propensity_design = make_design(data = data, vars = propensity$vars, id = id,
                                    num_lags = propensity$num_lags,
                                    basis = ifelse(is.null(propensity$basis), "linear", propensity$basis),
                                    degree = ifelse(is.null(propensity$degree), 2, propensity$degree),
                                    sigma = ifelse(is.null(propensity$sigma), 1, propensity$sigma),
                                    kernel_means = propensity$kernel_means)
    S3 = propensity_design$design_matrix
    all_ind = as.logical(pmin(state_value_design$indices, policy_design$indices,
                              propensity_design$indices))
  }

  # subset data and all design matrices to the indices above
  S1 = S1[all_ind, ]
  S2 = S2[all_ind, ]
  S3 = S3[all_ind, ]
  data = data[all_ind, ]

  # centers/scales covariates to be between 0 and 1 -- the intercept is not centered/scaled
  if (center_scale) {

    # center/scale S1
    to.center.S1 = apply(S1[ , -1], 2, min)
    to.scale.S1 = apply(S1[ , -1], 2, max) - apply(S1[ , -1], 2, min)
    center.scale.S1 = function(x) return(c(x[1], (x[-1] - to.center.S1) / to.scale.S1))
    S1 = t(apply(S1, 1, center.scale.S1))

    # center/scale S2
    to.center.S2 = apply(S2[ , -1], 2, min)
    to.scale.S2 = apply(S2[ , -1], 2, max) - apply(S2[ , -1], 2, min)
    center.scale.S2 = function(x) return(c(x[1], (x[-1] - to.center.S2) / to.scale.S2))
    S2 = t(apply(S2, 1, center.scale.S2))

    # center/scale S3
    to.center.S3 = apply(S3[ , -1], 2, min)
    to.scale.S3 = apply(S3[ , -1], 2, max) - apply(S3[ , -1], 2, min)
    center.scale.S3 = function(x) return(c(x[1], (x[-1] - to.center.S3) / to.scale.S3))
    S3 = t(apply(S3, 1, center.scale.S3))

  }  # end if center.scale

  # create predicted probabilities of observed treatments under observational policy --------------

  # create design matrix for treatment
  A = model.matrix(~ 0 + as.factor(data[[act]]))

  # if predicted probabilities are not provided, they are created here
  if (is.null(pred_prob)) {

    # if observational policy is not provided, it is estimated here
    if (is.null(mu)) {

      # more than two possible actions
      if (nlevels(as.factor(data[[act]])) > 2) {
        model = multinom(A ~ S3 + 0)
        pred = predict(model, type = "probs", newdata = S3)
        pred_prob = as.matrix(rowSums(A * pred))
      }  # end if more than two actions

      # two possible actions
      if (nlevels(as.factor(data[[act]])) == 2) {
        model = glm(A ~ S3 + 0, family = binomial(link = "logit"))
        pred.vals = as.matrix(model$fitted.values)
        pred_prob = as.matrix(pred.vals * A[ , 1] + (1 - pred.vals) * (A[ , 2]))
      }  # end if two actions

    }  # end if mu is null

    # if observational policy is provided, use it to create predicted probabilities
    if (!is.null(mu)) {
      pred_prob = rowSums(A * t(apply(S3, 1, mu)))
    }  # end if mu is not null

  } else {
      pred_prob = as.matrix(as.matrix(pred_prob)[all_ind, ])
  }

  # reference distribution and policy function ----------------------------------------------------

  # if reference distribution is not provided, estimate mean state variable from data
  if (is.null(ref)) nu = apply(S1, 2, mean)

  # if reference distribution is provided (mean state variables), use it as is
  if (is.numeric(ref) | is.matrix(ref)) nu = ref

  # policy function -- returns probability of an action, a, based on a state, s, and a policy, beta
  pi = function(s, a, beta) {
    # s is an ncol(S2) by 1 state vector
    # beta is a (ncol(S2) * (ncol(A) - 1)) by 1 parameter vector
    beta.mat = matrix(beta, nrow = ncol(A) - 1, ncol = ncol(S2), byrow = T)
    den = (1 + sum(apply(beta.mat %*% s, 1, exp)))
    if (which(a == 1) == ncol(A)) {
      return(1 / den)
    } else {
      return(exp(beta.mat[which(a == 1), ] %*% s) / den)
    }
  }  # end function pi

  # cross-validation to select lambda -------------------------------------------------------------

  # if a seed is provided, it is set here (SANN and CV are both stochastic)
  if (!is.null(seed)) set.seed(seed)

  # check if length of lambdas is larger than 1 before doing cross-validation
  if (length(lambdas) == 1) {
    lambda = lambdas[1]
  } else {

    # create folds for cross-validation
    folds = caret::createFolds(unique(data[[id]]), k = K)

    # estimate observational policy within the class of policies specified (defined by S2)

    # more than two possible actions
    if (nlevels(as.factor(data[[act]])) > 2) {
      model = multinom(A ~ S2 + 0)
      obs_beta = as.numeric(t(coef(model)))
      obs_pi = function(s, a) {
        # s is an ncol(S2) by 1 state vector
        # beta is a (ncol(S2) * (ncol(A) - 1)) by 1 parameter vector
        beta.mat = matrix(obs_beta, nrow = ncol(A) - 1, ncol = ncol(S2), byrow = T)
        den = (1 + sum(apply(beta.mat %*% s, 1, exp)))
        if (which(a == 1) == 1) {
          return(1 / den)
        } else {
          return(exp(beta.mat[which(a == 1) - 1, ] %*% s) / den)
        }
      }  # end function obs_pi
    }  # end if more than two actions

    # two possible actions
    if (nlevels(as.factor(data[[act]])) == 2) {
      model = glm(A ~ S2 + 0, family = binomial(link = "logit"))
      obs_beta = coef(model)
      obs_pi = function(s, a) {
        # s is an ncol(S2) by 1 state vector
        # beta is a (ncol(S2) * (ncol(A) - 1)) by 1 parameter vector
        beta.mat = matrix(obs_beta, nrow = ncol(A) - 1, ncol = ncol(S2), byrow = T)
        den = (1 + sum(apply(beta.mat %*% s, 1, exp)))
        if (which(a == 1) == 1) {
          return(1 / den)
        } else {
          return(exp(beta.mat[which(a == 1) - 1, ] %*% s) / den)
        }
      }  # end function obs_pi
    }  # end if two actions

    # errors for each lambdas
    errors = rep(NA, length(lambdas))

    # loop through lambdas
    for (j in 1:length(lambdas)) {

      # errors across folds
      errors_over_folds = rep(NA, K)

      for (k in 1:K) {

        # create training set
        train_data = data[which(data[[id]] %in% unlist(folds[-k])), ]
        train_S1 = S1[which(data[[id]] %in% unlist(folds[-k])), ]
        train_S2 = S2[which(data[[id]] %in% unlist(folds[-k])), ]
        train_A = A[which(data[[id]] %in% unlist(folds[-k])), ]
        train_pred_prob = pred_prob[which(data[[id]] %in% unlist(folds[-k])), ]

        # create testing set
        test_data = data[which(data[[id]] %in% unlist(folds[k])), ]
        test_S1 = S1[which(data[[id]] %in% unlist(folds[k])), ]
        test_S2 = S2[which(data[[id]] %in% unlist(folds[k])), ]
        test_A = A[which(data[[id]] %in% unlist(folds[k])), ]
        test_pred_prob = pred_prob[which(data[[id]] %in% unlist(folds[k])), ]

        # estimate state-value function on training set
        b.vec.list = list()
        A.mat.list = list()
        for (i in 1:length(unique(train_data[[id]]))) {
          indices = which(train_data[[id]] == unique(train_data[[id]])[i])
          for (t in 1:(length(indices) - 1)) {
            ind = indices[t]
            b.vec.list[[ind]] = -(1 / length(unique(train_data[[id]]))) * train_data[[util]][ind] * train_S1[ind, ]
            A.mat.list[[ind]] = (1 / length(unique(train_data[[id]]))) * (disc * train_S1[ind, ] %*% t(train_S1[ind + 1, ]) - train_S1[ind, ] %*% t(train_S1[ind, ]))
          }  # end loop through time points
          b.vec.list[[indices[length(indices)]]] = 0
          A.mat.list[[indices[length(indices)]]] = 0
        }  # end loop through ids
        comb.data = cbind(train_S2, train_A)
        app.pi = function(x) return(obs_pi(x[1:ncol(train_S2)], x[(ncol(train_S2) + 1):(ncol(train_S2) + ncol(train_A))]))
        applied.policy = apply(comb.data, 1, app.pi)
        imp = applied.policy / train_pred_prob

        b.vec = Reduce("+", mapply("*", imp, b.vec.list))
        A.mat = Reduce("+", mapply("*", imp, A.mat.list))

        if (lambdas[j] == 0) {
          temp_theta_hat = solve(A.mat, b.vec)
        }

        min.fun = function(theta) {
          temp = A.mat %*% theta - b.vec
          value = t(temp) %*% (temp) + lambdas[j] * norm_vec(theta[2:length(theta)])^2  # don't penalize intercept
          return(value)
        }

        init = matrix(1, nrow = nrow(A.mat), ncol = 1)
        out = optim(par = init, fn = min.fun, method = "BFGS", control = list(trace = 0))
        temp_theta_hat = out$par

        # estimate Bellman error on testing set
        b.vec.list = list()
        A.mat.list = list()
        for (i in 1:length(unique(test_data[[id]]))) {
          indices = which(test_data[[id]] == unique(test_data[[id]])[i])
          for (t in 1:(length(indices) - 1)) {
            ind = indices[t]
            b.vec.list[[ind]] = -(1 / length(unique(test_data[[id]]))) * test_data[[util]][ind] * test_S1[ind, ]
            A.mat.list[[ind]] = (1 / length(unique(test_data[[id]]))) * (disc * test_S1[ind, ] %*% t(test_S1[ind + 1, ]) - test_S1[ind, ] %*% t(test_S1[ind, ]))
          }  # end loop through time points
          b.vec.list[[indices[length(indices)]]] = 0
          A.mat.list[[indices[length(indices)]]] = 0
        }  # end loop through ids
        comb.data = cbind(test_S2, test_A)
        app.pi = function(x) return(obs_pi(x[1:ncol(test_S2)], x[(ncol(test_S2) + 1):(ncol(test_S2) + ncol(test_A))]))
        applied.policy = apply(comb.data, 1, app.pi)
        imp = applied.policy / test_pred_prob

        b.vec = Reduce("+", mapply("*", imp, b.vec.list))
        A.mat = Reduce("+", mapply("*", imp, A.mat.list))

        # save error for this fold
        temp = A.mat %*% temp_theta_hat - b.vec
        errors_over_folds[k] = t(temp) %*% (temp)

      }  # end loop through folds

      # save cross-validated error for this lambda
      errors[j] = mean(errors_over_folds)

    }  # end loop through lambdas

    # select lambda with smallest cross-validated error
    lambda = lambdas[which(errors == min(errors))]

  }  # end cross-validation

  # estimating equation for state-value function --------------------------------------------------

  # computation needed for estimating equation that can be done once, independent of beta
  b.vec.list = list()
  A.mat.list = list()
  for (i in 1:length(unique(data[[id]]))) {
    indices = which(data[[id]] == unique(data[[id]])[i])
    for (t in 1:(length(indices) - 1)) {
      ind = indices[t]
      b.vec.list[[ind]] = -(1 / length(unique(data[[id]]))) * data[[util]][ind] * S1[ind, ]
      A.mat.list[[ind]] = (1 / length(unique(data[[id]]))) * (disc * S1[ind, ] %*% t(S1[ind + 1, ]) - S1[ind, ] %*% t(S1[ind, ]))
    }  # end loop through time points
    b.vec.list[[indices[length(indices)]]] = 0
    A.mat.list[[indices[length(indices)]]] = 0
  }  # end loop through ids
  comb.data = cbind(S2, A)
  app.pi = function(x, beta) return(pi(x[1:ncol(S2)], x[(ncol(S2) + 1):(ncol(S2) + ncol(A))], beta))

  # function to solve the estimating equation
  solve.est = function(beta, lambda) {

    applied.policy = apply(comb.data, 1, app.pi, beta)
    imp = applied.policy / pred_prob

    b.vec = Reduce("+", mapply("*", imp, b.vec.list))
    A.mat = Reduce("+", mapply("*", imp, A.mat.list))

    if (lambda == 0) {
      theta_hat = solve(A.mat, b.vec)
      return(theta_hat)
    }

    min.fun = function(theta) {
      temp = A.mat %*% theta - b.vec
      value = t(temp) %*% (temp) + lambda * norm_vec(theta[2:length(theta)])^2  # don't penalize intercept
      return(value)
    }

    init = matrix(1, nrow = nrow(A.mat), ncol = 1)
    out = optim(par = init, fn = min.fun, method = "BFGS", control = list(trace = 0))
    theta_hat = out$par

    return(theta_hat)

  }  # end function solve.est

  # function to minimize
  # this function gives the negative estimated value
  value = function(beta, lambda, tau) {

    theta_hat = solve.est(beta, lambda)
    val = t(nu) %*% theta_hat - tau * norm_vec(beta)^2
    return(-val)

  }  # end value function

  # optimization to approximate the maximizer of the value function -------------------------------

  # set trace for tracking the optim function
  tr = 0

  # initial value to pass to optim
  init = matrix(rep(0, ncol(S2) * (ncol(A) - 1)))

  # simulated annealing to find starting point
  res.temp = optim(par = init, fn = value, method = "SANN", control = list(trace = tr, maxit = 1000), lambda = lambda, tau = tau)

  # set starting point for BFGS
  init.temp = res.temp$par

  # BFGS for optimizing value
  res = optim(par = init.temp, fn = value, method = "BFGS", control = list(trace = tr, maxit = 1000), lambda = lambda, tau = tau)

  # parameter for estimated policy
  beta_hat = res$par

  # parametric value estimate
  val_param = -res$value + tau * norm_vec(beta_hat)^2

  # solve for final theta_hat using final beta_hat
  theta_hat = solve.est(beta_hat, lambda)

  # confidence interval for parametric value estimate ---------------------------------------------

  comb.data = cbind(S2 , A)
  app.pi = function(x) return(pi(x[1:ncol(S2)], x[(ncol(S2) + 1):(ncol(S2) + ncol(A))], beta_hat))
  applied.policy = apply(comb.data, 1, app.pi)
  imp = applied.policy / pred_prob

  w.hat1 = matrix(0, nrow = ncol(S1), ncol = ncol(S1))
  w.hat0 = matrix(0, nrow = ncol(S1), ncol = ncol(S1))
  for (i in 1:length(unique(data[[id]]))) {
    indices = which(data[[id]] == unique(data[[id]])[i])
    for (t in 1:(length(indices) - 1)) {
      ind = indices[t]
      w.hat1 = w.hat1 + imp[ind] * matrix(S1[ind, ], ncol = 1) %*% matrix((S1[ind, ] - disc * S1[ind + 1, ]), nrow = 1)
      w.hat0 = w.hat0 + imp[ind]^2 * as.numeric((data[[util]][ind] + disc * matrix(S1[ind + 1, ], nrow = 1) %*% matrix(theta_hat, ncol = 1) - matrix(S1[ind, ], nrow = 1) %*% matrix(theta_hat, ncol = 1))^2) * (S1[ind, ] %*% t(S1[ind, ]))
    }  # end loop through time points
  }  # end loop through patients
  w.hat1 = w.hat1 * (1 / length(unique(data[[id]])))
  w.hat0 = w.hat0 * (1 / length(unique(data[[id]])))

  sigma_hat = sqrt(t(nu) %*% ginv(w.hat1) %*% w.hat0 %*% ginv(t(w.hat1)) %*% nu)

  z = qnorm(alpha / 2)
  se_hat = sigma_hat / sqrt(length(unique(data[[id]])))

  upper = val_param + abs(z) * se_hat
  lower = val_param - abs(z) * se_hat

  conf_int = c(lower, upper)
  names(conf_int) = c("lower", "upper")

  # create object to return and return ------------------------------------------------------------

  # a function to return probabilities of all actions for a policy defined by beta
  pi_all = function(s, beta) {
    # s is an ncol(S2) by 1 state vector
    # beta is a (ncol(S2) * (ncol(A)) - 1)) by 1 parameter vector
    beta.mat = matrix(beta, nrow = ncol(A) - 1, ncol = ncol(S2), byrow = T)
    den = (1 + sum(apply(beta.mat %*% s, 1, exp)))
    probs = rep(0, ncol(A))
    for (k in 1:(ncol(A) - 1)) {
      probs[k] = exp(beta.mat[k, ] %*% s) / den
    }
    probs[ncol(A)] = 1 / den  # last category is the reference category

    return(probs)

  }  # end function pi.all

  # final_policy takes as input a data frame (with the same columns as data) and a row number
  # it will construct the corresponding row from the design matrix (formed as S2 was formed)
  # it will return probabilities for each level of as.factor(data[[act]]) as recommended by policy
  final_policy = function(df, row_num) {

    # create design matrix for new data frame
    new_design = make_design(data = df, vars = policy_class$vars, id = id, num_lags = policy_class$num_lags,
                             basis = ifelse(is.null(policy_class$basis), "linear", policy_class$basis),
                             degree = ifelse(is.null(policy_class$degree), 2, policy_class$degree),
                             sigma = ifelse(is.null(policy_class$sigma), 1, policy_class$sigma),
                             kernel_means = policy_design$kernel_means)
    new_S = new_design$design_matrix

    # center and scale result if called for
    if(center_scale) {
      temp_S = t(apply(as.matrix(new_S), 1, center.scale.S2))
    } else {
      temp_S = new_S
    }

    # create object to return
    if (sum(is.na(temp_S[row_num])) == 0) {
      to_return = pi_all(temp_S[row_num, ], beta_hat)
    } else {
      to_return = rep(NA, nlevels(as.factor(data[[act]])))
    }
    names(to_return) = levels(as.factor(data[[act]]))

    return(to_return)

  }  # end function final_policy

  # create matrix of predicted probabilities (propensity scores) to return
  pred_to_return = rep(NA, length(all_ind))
  pred_to_return[all_ind] = pred_prob

  # create object to return
  to_return = list(beta_hat = beta_hat, theta_hat = theta_hat, final_policy = final_policy,
                   val_param = val_param, conf_int = conf_int, se_hat = se_hat,
                   best_lambda = lambda, pred_prob = pred_to_return)
  class(to_return) = "infiniteHorizon"

  return(to_return)

}  # end function vl

