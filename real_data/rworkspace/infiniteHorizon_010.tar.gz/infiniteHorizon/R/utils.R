# utils.R

# these are internal functions that will not be exported so there's not documentation

# function to compute vector norm
norm_vec = function(x) sqrt(sum(x^2))

# here goes functions for Gaussian basis functions
# return the value of a radial basis function
# bandwidth sigma is an argument
rbf = function(x, mu, sigma) return(exp(-(x - mu)^2 / (2 * sigma^2)))

# Gaussian basis
gauss = function(S, sigma) {
  n = dim(S)[1]
  capT = dim(S)[3]
  int = array(1, dim = c(n, 1, capT))
  new.S = int
  for (mu in seq(0, max(S), max(S) * sigma)) {
    S.temp = rbf(S, mu, max(S) * sigma)
    new.S = abind(new.S, S.temp, along = 2)
  }
  return(new.S)
}

# take two Sys.time() objects and return the difference in HH:MM:SS format
hms_span <- function(start, end) {
  dsec <- as.numeric(difftime(end, start, unit = "secs"))
  hours <- floor(dsec / 3600)
  minutes <- floor((dsec - 3600 * hours) / 60)
  seconds <- dsec - 3600 * hours - 60 * minutes
  paste0(
    sapply(c(hours, minutes, seconds), function(x) {
      formatC(x, width = 2, format = "d", flag = "0")
    }), collapse = ":")
}
