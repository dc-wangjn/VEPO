# make_design.R

# © 2019, The University of North Carolina at Chapel Hill. All rights reserved.

# this file contains the make_design function, which creates a design matrix for use with infiniteHorizon functions

#' Make design matrix
#'
#' \code{make_design} is used to create design matrices to model the state-value function,
#'   optimal policy, and observational policy in infiniteHorizon dynamic treatment regime
#'   functions.
#'
#' @param data A data frame.
#' @param vars A vector of character strings specifying the names of variables
#'   in \code{data} to include.
#' @param id A character string specifying the name of the patient identifier
#'   variable in \code{data}.
#' @param num_lags A numeric vector of the same length as \code{vars} containing the number of
#'   previous time points to include for each variable in \code{vars}. If \code{NULL}, set to a
#'   vector of ones and only the current value of each variable is used. Defaults to \code{NULL}.
#' @param basis A character string giving the type of basis functions to use. Can be
#'   any unambiguous substring of "linear," "polynomial," or "gaussian." Defaults to "linear."
#' @param degree Degree of polynomial to use. Ignored if basis is not "polynomial."
#'   Defaults to 2.
#' @param sigma Kernel bandwidth for Gaussian kernel. Ignored if basis is not "gaussian."
#'   Defaults to 0.5.
#' @param kernel_means A vector giving the means of the Gaussian basis functions.
#'   Ignored if basis is not "gaussian."
#'   Defaults to \code{NULL}, in which case the means of
#'   initial state variables are used.
#'
#' @return A list with the following components: \code{design_matrix}, a matrix with
#'   number of columns determined by the basis functions and number of time points, and
#'   at most \code{nrow(data)} rows, where rows from data have been removed when not
#'   enough time points were available; \code{indices}, a logical vector
#'   of length \code{nrow(data)}, equal to \code{TRUE} at indices for rows
#'   that were not removed; and \code{kernel_means}, the means for the Gaussian kernel functions,
#'   either the same ones that were supplied or those that were calculated (\code{NULL} if
#'   basis is not "gaussian").
#'
#' @export
#'
make_design = function(data, vars, id, num_lags = NULL, basis = "linear", degree = 2,
                       sigma = 1, kernel_means = NULL) {

  # if num_lags is NULL, set equal to a vector of ones
  if (is.null(num_lags)) num_lags = rep(1, length(vars))

  # create matrix with correct variables and number of time points
  S = NULL
  column_names = NULL
  for (k in unique(data[[id]])) {
    temp_data = data[which(data[[id]] == k), ]
    temp_S = NULL
    for (i in 1:length(vars)) {
      for (j in 1:num_lags[i]) {
        to.add = temp_data[ , which(names(temp_data) == vars[i])]
        if (j != 1) to.add = c(rep(NA, j - 1), to.add)
        to.add = to.add[1:nrow(temp_data)]
        temp_S = cbind(temp_S, to.add)
        if (k == unique(data[[id]])[length(unique(data[[id]]))]) {
          column_names = c(column_names, sprintf("%s_%s", vars[i], j))
        }
      }  # end loop through num_lags[i]
    }  # end loop through vars
    S = rbind(S, temp_S)
  }  # end loop through subjects

  # set column names of S
  colnames(S) = column_names

  # determine which rows did not have sufficient lag data and remove
  indices = complete.cases(S) # an indicator of which rows have sufficient data
  S = S[complete.cases(S), ]

  # create matrix with correct basis functions
  if (grepl(basis, "linear", ignore.case = T)) {
    S = cbind(1, S)
  }  # end linear basis

  if (grepl(basis, "polynomial", ignore.case = T)) {
    S = model.matrix( ~ poly(S, degree = degree, raw = T))
  }  # end polynomial basis

  if (grepl(basis, "gaussian", ignore.case = T)) {
    if (is.null(kernel_means)) {
      new_data = data[indices, ]
      kernel_means = S[which(!duplicated(new_data[[id]])), ]
    }
    kernmat = kernelMatrix(rbfdot(sigma = sigma), x = S,
                           y = kernel_means)
    S = cbind(1, kernmat@.Data)
  }  # end gaussian basis

  # assemble design matrix (with missing values in place of rows with insufficient data)
  final_design = matrix(NA, nrow = nrow(data), ncol = ncol(S))
  final_design[indices, ] = S

  # return design matrix and vector of indicators of rows with sufficient data
  to_return = list(design_matrix = final_design, indices = indices, kernel_means = kernel_means)

  return(to_return)

}  # end function make_design
