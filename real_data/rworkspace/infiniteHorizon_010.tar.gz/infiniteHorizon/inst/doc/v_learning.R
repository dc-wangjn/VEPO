## ----generate_example_data, message = FALSE, collapse = TRUE-------------
library(infiniteHorizon)
set.seed(10)
example_data = genmod1(n = 50, capT = 25, mu = NULL, init = NULL)

## ----head_example_data, collapse = TRUE----------------------------------
head(example_data)

## ----beta_hat, collapse = TRUE-------------------------------------------
vl_example$beta_hat

## ----parametric_value, collapse = TRUE-----------------------------------
vl_example$val_param
vl_example$conf_int

## ----simulated_value, collapse = TRUE------------------------------------
test_data = genmod1(n = 50, capT = 25, mu = vl_example$final_policy)
mean(test_data$util, na.rm = TRUE)
mean(example_data$util, na.rm = TRUE)

## ----display_offline_results, echo = FALSE, collapse = TRUE--------------
knitr::kable(results_by_model)

## ----display_online_results, echo = FALSE, collapse = TRUE---------------
knitr::kable(results_over_time)

